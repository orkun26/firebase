<template>
  <section class="pattern-group pattern-group-t-0 pattern-group-p-home">
    <div class="container">
      <div class="pattern-group-body">
        <div class="row">
          <div
            class="col-list col-12 d-block col-sm-12 d-sm-block col-md-12 d-md-block col-lg-12 d-lg-block col-xl-12 d-xl-block p-g-b-c-0"
          >
            <div class="p-g-b-c-wrapper">
              <div class="p-g-b-c-inner">
                <div
                  class="p-g-mod p-g-mod-t-44 p-g-mod-showcase p-g-mod-trans"
                >
                  <div class="p-g-mod-body p-g-mod-body-p-0">
                    <div class="row-wrapper">
                      <div class="row custom-module-code-91">
                        <div
                          class="col-6 col-sm-6 col-md-6 col-lg-4 col-xl-4 col-list-p-v-1"
                        >
                          <nuxt-link
                            :to="'/urun-detay/1'"
                            class="banner-item"
                            ><div class="image">
                              <img
                                class="lazy-load lazy-complete"
                                alt=""
                                src="../assets/Body/Body1.png"
                                style=""
                              /></div
                          ></nuxt-link>
                        </div>
                        <div
                          class="col-6 col-sm-6 col-md-6 col-lg-4 col-xl-4 col-list-p-v-1"
                        >
                          <nuxt-link
                            :to="'/urun-detay/2'"
                            class="banner-item"
                            ><div class="image">
                              <img
                                class="lazy-load lazy-complete"
                                alt=""
                                src="../assets/Body/Body2.png"
                                style=""
                              /></div
                          ></nuxt-link>
                        </div>
                        <div
                          class="col-6 col-sm-6 col-md-6 col-lg-4 col-xl-4 col-list-p-v-1"
                        >
                           <nuxt-link
                            :to="'/urun-detay/3'"
                            class="banner-item"
                            ><div class="image">
                              <img
                                class="lazy-load lazy-complete"
                                alt=""
                                src="../assets/Body/Body3.png"
                                style=""
                              /></div
                          ></nuxt-link>
                        </div>
                        <div
                          class="col-6 col-sm-6 col-md-6 col-lg-4 col-xl-4 col-list-p-v-1"
                        >
                           <nuxt-link
                            :to="'/urun-detay/4'"
                            class="banner-item"
                            ><div class="image">
                              <img
                                class="lazy-load lazy-complete"
                                alt=""
                                src="../assets/Body/Body4.png"
                                style=""
                              /></div
                          ></nuxt-link>
                        </div>
                        <div
                          class="col-6 col-sm-6 col-md-6 col-lg-4 col-xl-4 col-list-p-v-1"
                        >
                          <nuxt-link
                            :to="'/urun-detay/5'"
                            class="banner-item"
                            ><div class="image">
                              <img
                                class="lazy-load lazy-complete"
                                alt=""
                                src="../assets/Body/Body5.png"
                                style=""
                              /></div
                          ></nuxt-link>
                        </div>
                        <div
                          class="col-6 col-sm-6 col-md-6 col-lg-4 col-xl-4 col-list-p-v-1"
                        >
                           <nuxt-link
                            :to="'/urun-detay/6'"
                            class="banner-item"
                            ><div class="image">
                              <img
                                class="lazy-load lazy-complete"
                                alt=""
                                src="../assets/Body/Body6.png"
                                style=""
                              /></div
                          ></nuxt-link>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </section>
</template>
    
