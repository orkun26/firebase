<template>
  <section class="pattern-group pattern-group-t-0 pattern-group-p-categories">
    <div class="container">
      <div class="pattern-group-body">
        <div class="row">
          <div
            class="col-list col-0 d-none col-sm-0 d-sm-none col-md-0 d-md-none col-lg-3 d-lg-block col-xl-3 d-xl-block p-g-b-c-0"
          >
            <div class="p-g-b-c-wrapper">
              <div class="p-g-b-c-inner">
                <div
                  class="p-g-mod p-g-mod-t-35 p-g-mod-t-cat-filter p-g-mod-trans"
                  style="display: none"
                >
                  <div class="p-g-mod-body p-g-mod-body-p-0">
                    <div class="text-center">
                      <div class="spinner-border text-secondary" role="status">
                        <span class="sr-only">Yükleniyor...</span>
                      </div>
                    </div>
                  </div>
                </div>
                <div
                  class="p-g-mod p-g-mod-t-21 p-g-mod-t-cat-filter p-g-mod-trans p-g-mod-t-cat-display-0"
                  style="display: block"
                >
                  <div class="p-g-mod-header p-g-mod-header-p-0">
                    <div class="p-g-m-h-info">
                      <div class="p-g-m-h-i-title">Alt Kategoriler</div>
                    </div>
                  </div>
                  <div class="p-g-mod-body p-g-mod-body-p-0">
                    <div
                      class="category-filter-list cat-display-type-0"
                      data-smart-cat-filter="sub-categories"
                    >
                      <div
                        class="list-wrap"
                        data-simplebar="init"
                        data-simplebar-auto-hide="false"
                      >
                        <div
                          class="simplebar-track vertical"
                          style="visibility: hidden"
                        >
                          <div class="simplebar-scrollbar"></div>
                        </div>
                        <div
                          class="simplebar-track horizontal"
                          style="visibility: visible"
                        >
                          <div
                            class="simplebar-scrollbar visible"
                            style="visibility: visible; left: 0px; width: 25px"
                          ></div>
                        </div>
                        <div
                          class="simplebar-scroll-content"
                          style="padding-right: 17px; margin-bottom: -34px"
                        >
                          <div
                            class="simplebar-content"
                            style="padding-bottom: 17px; margin-right: -17px"
                          >
                            <ul class="list">
                              <li class="">
                                <a
                                  href="/elektronik/mobil-mobil-aksesuar-c-185"
                                  title="Mobil &amp; Mobil Aksesuar"
                                  >Mobil &amp; Mobil Aksesuar</a
                                >
                              </li>
                              <li class="">
                                <a
                                  href="/elektronik/akilli-saat-bileklikler-c-155"
                                  title="Akıllı Saat &amp; Bileklikler"
                                  >Akıllı Saat &amp; Bileklikler</a
                                >
                              </li>
                              <li class="">
                                <a
                                  href="/elektronik/aydinlatma-sistemleri-c-156"
                                  title="Aydınlatma Sistemleri"
                                  >Aydınlatma Sistemleri</a
                                >
                              </li>
                              <li class="">
                                <a
                                  href="/elektronik/bilgisayar-tablet-c-157"
                                  title="Bilgisayar &amp; Tablet"
                                  >Bilgisayar &amp; Tablet</a
                                >
                              </li>
                              <li class="">
                                <a
                                  href="/elektronik/kucuk-ev-aletleri-c-158"
                                  title="Küçük Ev Aletleri"
                                  >Küçük Ev Aletleri</a
                                >
                              </li>
                              <li class="">
                                <a
                                  href="/elektronik/tv-goruntu-ses-sistemleri-c-159"
                                  title="TV, Görüntü &amp; Ses Sistemleri"
                                  >TV, Görüntü &amp; Ses Sistemleri</a
                                >
                              </li>
                            </ul>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
                <div
                  class="p-g-mod p-g-mod-t-22 p-g-mod-t-cat-filter p-g-mod-trans p-g-mod-t-cat-display-0"
                  style="display: block"
                >
                  <div class="p-g-mod-header p-g-mod-header-p-0">
                    <div class="p-g-m-h-info">
                      <div class="p-g-m-h-i-title">Markalar</div>
                    </div>
                  </div>
                  <div class="p-g-mod-body p-g-mod-body-p-0">
                    <div
                      class="category-filter-list"
                      data-smart-cat-filter="brands"
                    >
                      <div
                        class="list-wrap"
                        data-simplebar="init"
                        data-simplebar-auto-hide="false"
                      >
                        <div
                          class="simplebar-track vertical"
                          style="visibility: visible"
                        >
                          <div
                            class="simplebar-scrollbar visible"
                            style="visibility: visible; top: 0px; height: 53px"
                          ></div>
                        </div>
                        <div
                          class="simplebar-track horizontal"
                          style="visibility: visible"
                        >
                          <div
                            class="simplebar-scrollbar visible"
                            style="visibility: visible; left: 0px; width: 25px"
                          ></div>
                        </div>
                        <div
                          class="simplebar-scroll-content"
                          style="padding-right: 17px; margin-bottom: -34px"
                        >
                          <div
                            class="simplebar-content"
                            style="padding-bottom: 17px; margin-right: -17px"
                          >
                            <ul class="list">
                              <li>
                                <div class="lag-checkbox">
                                  <input
                                    id="cat-filter-brand-72"
                                    name="smart-cat-markalar[]"
                                    value="72"
                                    data-smart-cat-search="1"
                                    type="checkbox"
                                  /><label for="cat-filter-brand-72">Dat</label
                                  ><span></span>
                                </div>
                              </li>
                              <li>
                                <div class="lag-checkbox">
                                  <input
                                    id="cat-filter-brand-67"
                                    name="smart-cat-markalar[]"
                                    value="67"
                                    data-smart-cat-search="1"
                                    type="checkbox"
                                  /><label for="cat-filter-brand-67"
                                    >Dearling</label
                                  ><span></span>
                                </div>
                              </li>
                              <li>
                                <div class="lag-checkbox">
                                  <input
                                    id="cat-filter-brand-57"
                                    name="smart-cat-markalar[]"
                                    value="57"
                                    data-smart-cat-search="1"
                                    type="checkbox"
                                  /><label for="cat-filter-brand-57"
                                    >Dextel</label
                                  ><span></span>
                                </div>
                              </li>
                              <li>
                                <div class="lag-checkbox">
                                  <input
                                    id="cat-filter-brand-73"
                                    name="smart-cat-markalar[]"
                                    value="73"
                                    data-smart-cat-search="1"
                                    type="checkbox"
                                  /><label for="cat-filter-brand-73"
                                    >Diamond</label
                                  ><span></span>
                                </div>
                              </li>
                              <li>
                                <div class="lag-checkbox">
                                  <input
                                    id="cat-filter-brand-226"
                                    name="smart-cat-markalar[]"
                                    value="226"
                                    data-smart-cat-search="1"
                                    type="checkbox"
                                  /><label for="cat-filter-brand-226"
                                    >Egonex</label
                                  ><span></span>
                                </div>
                              </li>
                              <li>
                                <div class="lag-checkbox">
                                  <input
                                    id="cat-filter-brand-56"
                                    name="smart-cat-markalar[]"
                                    value="56"
                                    data-smart-cat-search="1"
                                    type="checkbox"
                                  /><label for="cat-filter-brand-56"
                                    >Emrtech</label
                                  ><span></span>
                                </div>
                              </li>
                              <li>
                                <div class="lag-checkbox">
                                  <input
                                    id="cat-filter-brand-22"
                                    name="smart-cat-markalar[]"
                                    value="22"
                                    data-smart-cat-search="1"
                                    type="checkbox"
                                  /><label for="cat-filter-brand-22"
                                    >Everton</label
                                  ><span></span>
                                </div>
                              </li>
                              <li>
                                <div class="lag-checkbox">
                                  <input
                                    id="cat-filter-brand-84"
                                    name="smart-cat-markalar[]"
                                    value="84"
                                    data-smart-cat-search="1"
                                    type="checkbox"
                                  /><label for="cat-filter-brand-84">Fepe</label
                                  ><span></span>
                                </div>
                              </li>
                              <li>
                                <div class="lag-checkbox">
                                  <input
                                    id="cat-filter-brand-86"
                                    name="smart-cat-markalar[]"
                                    value="86"
                                    data-smart-cat-search="1"
                                    type="checkbox"
                                  /><label for="cat-filter-brand-86"
                                    >Fineblue </label
                                  ><span></span>
                                </div>
                              </li>
                              <li>
                                <div class="lag-checkbox">
                                  <input
                                    id="cat-filter-brand-50"
                                    name="smart-cat-markalar[]"
                                    value="50"
                                    data-smart-cat-search="1"
                                    type="checkbox"
                                  /><label for="cat-filter-brand-50"
                                    >Forland</label
                                  ><span></span>
                                </div>
                              </li>
                              <li>
                                <div class="lag-checkbox">
                                  <input
                                    id="cat-filter-brand-21"
                                    name="smart-cat-markalar[]"
                                    value="21"
                                    data-smart-cat-search="1"
                                    type="checkbox"
                                  /><label for="cat-filter-brand-21"
                                    >Gold Htc </label
                                  ><span></span>
                                </div>
                              </li>
                              <li>
                                <div class="lag-checkbox">
                                  <input
                                    id="cat-filter-brand-16"
                                    name="smart-cat-markalar[]"
                                    value="16"
                                    data-smart-cat-search="1"
                                    type="checkbox"
                                  /><label for="cat-filter-brand-16"
                                    >Gold Kama</label
                                  ><span></span>
                                </div>
                              </li>
                              <li>
                                <div class="lag-checkbox">
                                  <input
                                    id="cat-filter-brand-91"
                                    name="smart-cat-markalar[]"
                                    value="91"
                                    data-smart-cat-search="1"
                                    type="checkbox"
                                  /><label for="cat-filter-brand-91"
                                    >Gold Silver </label
                                  ><span></span>
                                </div>
                              </li>
                              <li>
                                <div class="lag-checkbox">
                                  <input
                                    id="cat-filter-brand-24"
                                    name="smart-cat-markalar[]"
                                    value="24"
                                    data-smart-cat-search="1"
                                    type="checkbox"
                                  /><label for="cat-filter-brand-24"
                                    >Greyder</label
                                  ><span></span>
                                </div>
                              </li>
                              <li>
                                <div class="lag-checkbox">
                                  <input
                                    id="cat-filter-brand-103"
                                    name="smart-cat-markalar[]"
                                    value="103"
                                    data-smart-cat-search="1"
                                    type="checkbox"
                                  /><label for="cat-filter-brand-103"
                                    >IPONE</label
                                  ><span></span>
                                </div>
                              </li>
                              <li>
                                <div class="lag-checkbox">
                                  <input
                                    id="cat-filter-brand-94"
                                    name="smart-cat-markalar[]"
                                    value="94"
                                    data-smart-cat-search="1"
                                    type="checkbox"
                                  /><label for="cat-filter-brand-94"
                                    >Kadio</label
                                  ><span></span>
                                </div>
                              </li>
                              <li>
                                <div class="lag-checkbox">
                                  <input
                                    id="cat-filter-brand-106"
                                    name="smart-cat-markalar[]"
                                    value="106"
                                    data-smart-cat-search="1"
                                    type="checkbox"
                                  /><label for="cat-filter-brand-106"
                                    >Kamal</label
                                  ><span></span>
                                </div>
                              </li>
                              <li>
                                <div class="lag-checkbox">
                                  <input
                                    id="cat-filter-brand-108"
                                    name="smart-cat-markalar[]"
                                    value="108"
                                    data-smart-cat-search="1"
                                    type="checkbox"
                                  /><label for="cat-filter-brand-108"
                                    >Kemai</label
                                  ><span></span>
                                </div>
                              </li>
                              <li>
                                <div class="lag-checkbox">
                                  <input
                                    id="cat-filter-brand-34"
                                    name="smart-cat-markalar[]"
                                    value="34"
                                    data-smart-cat-search="1"
                                    type="checkbox"
                                  /><label for="cat-filter-brand-34"
                                    >Kingboss</label
                                  ><span></span>
                                </div>
                              </li>
                              <li>
                                <div class="lag-checkbox">
                                  <input
                                    id="cat-filter-brand-7"
                                    name="smart-cat-markalar[]"
                                    value="7"
                                    data-smart-cat-search="1"
                                    type="checkbox"
                                  /><label for="cat-filter-brand-7"
                                    >Kingshark</label
                                  ><span></span>
                                </div>
                              </li>
                              <li>
                                <div class="lag-checkbox">
                                  <input
                                    id="cat-filter-brand-130"
                                    name="smart-cat-markalar[]"
                                    value="130"
                                    data-smart-cat-search="1"
                                    type="checkbox"
                                  /><label for="cat-filter-brand-130"
                                    >Knstar</label
                                  ><span></span>
                                </div>
                              </li>
                              <li>
                                <div class="lag-checkbox">
                                  <input
                                    id="cat-filter-brand-32"
                                    name="smart-cat-markalar[]"
                                    value="32"
                                    data-smart-cat-search="1"
                                    type="checkbox"
                                  /><label for="cat-filter-brand-32"
                                    >Magic Bag </label
                                  ><span></span>
                                </div>
                              </li>
                              <li>
                                <div class="lag-checkbox">
                                  <input
                                    id="cat-filter-brand-123"
                                    name="smart-cat-markalar[]"
                                    value="123"
                                    data-smart-cat-search="1"
                                    type="checkbox"
                                  /><label for="cat-filter-brand-123"
                                    >Mega</label
                                  ><span></span>
                                </div>
                              </li>
                              <li>
                                <div class="lag-checkbox">
                                  <input
                                    id="cat-filter-brand-120"
                                    name="smart-cat-markalar[]"
                                    value="120"
                                    data-smart-cat-search="1"
                                    type="checkbox"
                                  /><label for="cat-filter-brand-120"
                                    >Meier</label
                                  ><span></span>
                                </div>
                              </li>
                              <li>
                                <div class="lag-checkbox">
                                  <input
                                    id="cat-filter-brand-132"
                                    name="smart-cat-markalar[]"
                                    value="132"
                                    data-smart-cat-search="1"
                                    type="checkbox"
                                  /><label for="cat-filter-brand-132"
                                    >Motorola</label
                                  ><span></span>
                                </div>
                              </li>
                              <li>
                                <div class="lag-checkbox">
                                  <input
                                    id="cat-filter-brand-17"
                                    name="smart-cat-markalar[]"
                                    value="17"
                                    data-smart-cat-search="1"
                                    type="checkbox"
                                  /><label for="cat-filter-brand-17"
                                    >Mytech</label
                                  ><span></span>
                                </div>
                              </li>
                              <li>
                                <div class="lag-checkbox">
                                  <input
                                    id="cat-filter-brand-134"
                                    name="smart-cat-markalar[]"
                                    value="134"
                                    data-smart-cat-search="1"
                                    type="checkbox"
                                  /><label for="cat-filter-brand-134"
                                    >Navigold</label
                                  ><span></span>
                                </div>
                              </li>
                              <li>
                                <div class="lag-checkbox">
                                  <input
                                    id="cat-filter-brand-36"
                                    name="smart-cat-markalar[]"
                                    value="36"
                                    data-smart-cat-search="1"
                                    type="checkbox"
                                  /><label for="cat-filter-brand-36"
                                    >New Swan</label
                                  ><span></span>
                                </div>
                              </li>
                              <li>
                                <div class="lag-checkbox">
                                  <input
                                    id="cat-filter-brand-29"
                                    name="smart-cat-markalar[]"
                                    value="29"
                                    data-smart-cat-search="1"
                                    type="checkbox"
                                  /><label for="cat-filter-brand-29"
                                    >Nikula</label
                                  ><span></span>
                                </div>
                              </li>
                              <li>
                                <div class="lag-checkbox">
                                  <input
                                    id="cat-filter-brand-1"
                                    name="smart-cat-markalar[]"
                                    value="1"
                                    data-smart-cat-search="1"
                                    type="checkbox"
                                  /><label for="cat-filter-brand-1"
                                    >Noname</label
                                  ><span></span>
                                </div>
                              </li>
                              <li>
                                <div class="lag-checkbox">
                                  <input
                                    id="cat-filter-brand-59"
                                    name="smart-cat-markalar[]"
                                    value="59"
                                    data-smart-cat-search="1"
                                    type="checkbox"
                                  /><label for="cat-filter-brand-59"
                                    >Nordmende</label
                                  ><span></span>
                                </div>
                              </li>
                              <li>
                                <div class="lag-checkbox">
                                  <input
                                    id="cat-filter-brand-11"
                                    name="smart-cat-markalar[]"
                                    value="11"
                                    data-smart-cat-search="1"
                                    type="checkbox"
                                  /><label for="cat-filter-brand-11"
                                    >Platoon</label
                                  ><span></span>
                                </div>
                              </li>
                              <li>
                                <div class="lag-checkbox">
                                  <input
                                    id="cat-filter-brand-2"
                                    name="smart-cat-markalar[]"
                                    value="2"
                                    data-smart-cat-search="1"
                                    type="checkbox"
                                  /><label for="cat-filter-brand-2"
                                    >PolyGold</label
                                  ><span></span>
                                </div>
                              </li>
                              <li>
                                <div class="lag-checkbox">
                                  <input
                                    id="cat-filter-brand-12"
                                    name="smart-cat-markalar[]"
                                    value="12"
                                    data-smart-cat-search="1"
                                    type="checkbox"
                                  /><label for="cat-filter-brand-12"
                                    >Powerstar</label
                                  ><span></span>
                                </div>
                              </li>
                              <li>
                                <div class="lag-checkbox">
                                  <input
                                    id="cat-filter-brand-176"
                                    name="smart-cat-markalar[]"
                                    value="176"
                                    data-smart-cat-search="1"
                                    type="checkbox"
                                  /><label for="cat-filter-brand-176"
                                    >Pugb</label
                                  ><span></span>
                                </div>
                              </li>
                              <li>
                                <div class="lag-checkbox">
                                  <input
                                    id="cat-filter-brand-153"
                                    name="smart-cat-markalar[]"
                                    value="153"
                                    data-smart-cat-search="1"
                                    type="checkbox"
                                  /><label for="cat-filter-brand-153"
                                    >Roxy</label
                                  ><span></span>
                                </div>
                              </li>
                              <li>
                                <div class="lag-checkbox">
                                  <input
                                    id="cat-filter-brand-170"
                                    name="smart-cat-markalar[]"
                                    value="170"
                                    data-smart-cat-search="1"
                                    type="checkbox"
                                  /><label for="cat-filter-brand-170"
                                    >Ttec</label
                                  ><span></span>
                                </div>
                              </li>
                              <li>
                                <div class="lag-checkbox">
                                  <input
                                    id="cat-filter-brand-53"
                                    name="smart-cat-markalar[]"
                                    value="53"
                                    data-smart-cat-search="1"
                                    type="checkbox"
                                  /><label for="cat-filter-brand-53"
                                    >Tuğraçelik</label
                                  ><span></span>
                                </div>
                              </li>
                              <li>
                                <div class="lag-checkbox">
                                  <input
                                    id="cat-filter-brand-9"
                                    name="smart-cat-markalar[]"
                                    value="9"
                                    data-smart-cat-search="1"
                                    type="checkbox"
                                  /><label for="cat-filter-brand-9"
                                    >Tv Shop </label
                                  ><span></span>
                                </div>
                              </li>
                              <li>
                                <div class="lag-checkbox">
                                  <input
                                    id="cat-filter-brand-48"
                                    name="smart-cat-markalar[]"
                                    value="48"
                                    data-smart-cat-search="1"
                                    type="checkbox"
                                  /><label for="cat-filter-brand-48"
                                    >Watton</label
                                  ><span></span>
                                </div>
                              </li>
                              <li>
                                <div class="lag-checkbox">
                                  <input
                                    id="cat-filter-brand-15"
                                    name="smart-cat-markalar[]"
                                    value="15"
                                    data-smart-cat-search="1"
                                    type="checkbox"
                                  /><label for="cat-filter-brand-15"
                                    >Xiaomi</label
                                  ><span></span>
                                </div>
                              </li>
                            </ul>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
                <div
                  class="p-g-mod p-g-mod-t-23 p-g-mod-t-cat-filter p-g-mod-trans p-g-mod-t-cat-display-0"
                  style="display: none"
                >
                  <div class="p-g-mod-header p-g-mod-header-p-0">
                    <div class="p-g-m-h-info">
                      <div class="p-g-m-h-i-title">Nitelikler</div>
                    </div>
                  </div>
                  <div class="p-g-mod-body p-g-mod-body-p-0">
                    <div
                      class="category-filter-list"
                      data-smart-cat-filter="attributes"
                    ></div>
                  </div>
                </div>
                <div
                  class="p-g-mod p-g-mod-t-24 p-g-mod-t-cat-filter p-g-mod-trans p-g-mod-t-cat-display-0"
                  style="display: block"
                >
                  <div class="p-g-mod-header p-g-mod-header-p-0">
                    <div class="p-g-m-h-info">
                      <div class="p-g-m-h-i-title">Fiyat Aralıkları</div>
                    </div>
                  </div>
                  <div class="p-g-mod-body p-g-mod-body-p-0">
                    <div
                      class="category-filter-list"
                      data-smart-cat-filter="price-ranges"
                    >
                      <div
                        class="list-wrap"
                        data-simplebar="init"
                        data-simplebar-auto-hide="false"
                      >
                        <div
                          class="simplebar-track vertical"
                          style="visibility: visible"
                        >
                          <div
                            class="simplebar-scrollbar visible"
                            style="visibility: visible; top: 0px; height: 221px"
                          ></div>
                        </div>
                        <div
                          class="simplebar-track horizontal"
                          style="visibility: visible"
                        >
                          <div
                            class="simplebar-scrollbar visible"
                            style="visibility: visible; left: 0px; width: 25px"
                          ></div>
                        </div>
                        <div
                          class="simplebar-scroll-content"
                          style="padding-right: 17px; margin-bottom: -34px"
                        >
                          <div
                            class="simplebar-content"
                            style="padding-bottom: 17px; margin-right: -17px"
                          >
                            <ul class="list">
                              <li>
                                <div class="lag-checkbox">
                                  <input
                                    id="cat-filter-price-70-alt"
                                    name="smart-cat-fiyatlar"
                                    value="70-alt"
                                    data-smart-cat-search="1"
                                    type="radio"
                                  /><label for="cat-filter-price-70-alt"
                                    >70 TL ve altı</label
                                  ><span></span>
                                </div>
                              </li>
                              <li>
                                <div class="lag-checkbox">
                                  <input
                                    id="cat-filter-price-70-139"
                                    name="smart-cat-fiyatlar"
                                    value="70-139"
                                    data-smart-cat-search="1"
                                    type="radio"
                                  /><label for="cat-filter-price-70-139"
                                    >70 TL - 139 TL</label
                                  ><span></span>
                                </div>
                              </li>
                              <li>
                                <div class="lag-checkbox">
                                  <input
                                    id="cat-filter-price-139-209"
                                    name="smart-cat-fiyatlar"
                                    value="139-209"
                                    data-smart-cat-search="1"
                                    type="radio"
                                  /><label for="cat-filter-price-139-209"
                                    >139 TL - 209 TL</label
                                  ><span></span>
                                </div>
                              </li>
                              <li>
                                <div class="lag-checkbox">
                                  <input
                                    id="cat-filter-price-209-279"
                                    name="smart-cat-fiyatlar"
                                    value="209-279"
                                    data-smart-cat-search="1"
                                    type="radio"
                                  /><label for="cat-filter-price-209-279"
                                    >209 TL - 279 TL</label
                                  ><span></span>
                                </div>
                              </li>
                              <li>
                                <div class="lag-checkbox">
                                  <input
                                    id="cat-filter-price-279-349"
                                    name="smart-cat-fiyatlar"
                                    value="279-349"
                                    data-smart-cat-search="1"
                                    type="radio"
                                  /><label for="cat-filter-price-279-349"
                                    >279 TL - 349 TL</label
                                  ><span></span>
                                </div>
                              </li>
                              <li>
                                <div class="lag-checkbox">
                                  <input
                                    id="cat-filter-price-349-419"
                                    name="smart-cat-fiyatlar"
                                    value="349-419"
                                    data-smart-cat-search="1"
                                    type="radio"
                                  /><label for="cat-filter-price-349-419"
                                    >349 TL - 419 TL</label
                                  ><span></span>
                                </div>
                              </li>
                              <li>
                                <div class="lag-checkbox">
                                  <input
                                    id="cat-filter-price-419-489"
                                    name="smart-cat-fiyatlar"
                                    value="419-489"
                                    data-smart-cat-search="1"
                                    type="radio"
                                  /><label for="cat-filter-price-419-489"
                                    >419 TL - 489 TL</label
                                  ><span></span>
                                </div>
                              </li>
                              <li>
                                <div class="lag-checkbox">
                                  <input
                                    id="cat-filter-price-489-559"
                                    name="smart-cat-fiyatlar"
                                    value="489-559"
                                    data-smart-cat-search="1"
                                    type="radio"
                                  /><label for="cat-filter-price-489-559"
                                    >489 TL - 559 TL</label
                                  ><span></span>
                                </div>
                              </li>
                              <li>
                                <div class="lag-checkbox">
                                  <input
                                    id="cat-filter-price-559-629"
                                    name="smart-cat-fiyatlar"
                                    value="559-629"
                                    data-smart-cat-search="1"
                                    type="radio"
                                  /><label for="cat-filter-price-559-629"
                                    >559 TL - 629 TL</label
                                  ><span></span>
                                </div>
                              </li>
                              <li>
                                <div class="lag-checkbox">
                                  <input
                                    id="cat-filter-price-629-uzeri"
                                    name="smart-cat-fiyatlar"
                                    value="629-uzeri"
                                    data-smart-cat-search="1"
                                    type="radio"
                                  /><label for="cat-filter-price-629-uzeri"
                                    >629 TL ve üzeri</label
                                  ><span></span>
                                </div>
                              </li>
                            </ul>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
                <div
                  class="p-g-mod p-g-mod-t-25 p-g-mod-t-cat-filter p-g-mod-trans p-g-mod-t-cat-display-0"
                  style="display: block"
                >
                  <div class="p-g-mod-header p-g-mod-header-p-0">
                    <div class="p-g-m-h-info">
                      <div class="p-g-m-h-i-title">Listeleme</div>
                    </div>
                  </div>
                  <div class="p-g-mod-body p-g-mod-body-p-0">
                    <div class="category-filter-list">
                      <div
                        class="list-wrap"
                        data-simplebar="init"
                        data-simplebar-auto-hide="false"
                      >
                        <div
                          class="simplebar-track vertical"
                          style="visibility: hidden"
                        >
                          <div class="simplebar-scrollbar"></div>
                        </div>
                        <div
                          class="simplebar-track horizontal"
                          style="visibility: visible"
                        >
                          <div
                            class="simplebar-scrollbar visible"
                            style="visibility: visible; left: 0px; width: 25px"
                          ></div>
                        </div>
                        <div
                          class="simplebar-scroll-content"
                          style="padding-right: 17px; margin-bottom: -34px"
                        >
                          <div
                            class="simplebar-content"
                            style="padding-bottom: 17px; margin-right: -17px"
                          >
                            <ul class="list">
                              <li>
                                <div class="lag-checkbox">
                                  <input
                                    id="cat-filter-list-stoktakiler"
                                    name="smart-cat-list"
                                    value="stoktakiler"
                                    data-smart-cat-search="1"
                                    type="radio"
                                  /><label for="cat-filter-list-stoktakiler"
                                    >Sadece stoktakileri göster</label
                                  ><span></span>
                                </div>
                              </li>
                            </ul>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
                <div
                  class="p-g-mod p-g-mod-t-26 p-g-mod-trans p-g-mod-t-cat-display-0"
                  style="display: block"
                >
                  <div class="p-g-mod-body p-g-mod-body-p-0">
                    <div class="buttons">
                      <a
                        href="/elektronik-c-154"
                        class="btn btn-secondary"
                      >
                        Seçimleri Temizle </a
                      ><a
                        href="javascript:;"
                        onclick="hideSmartCategoryPopup()"
                        class="btn btn-success d-block d-sm-block d-md-block d-lg-none"
                      >
                        Ürünleri Gör
                      </a>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </section>
</template>
