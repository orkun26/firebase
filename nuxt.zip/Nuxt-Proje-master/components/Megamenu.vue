<template>
  <section class="menu">
    <div class="container">
      <div class="mega-menu">
        <ul class="navbar-nav mr-auto">
          <li class="nav-item dropdown">
            <a
              class="nav-link dropdown-toggle"
              href="/11-yila-ozel-c-194"
              id="mega-menu-194"
              role="button"
            >
              11. Yıla Özel
            </a>
          </li>
          <li class="nav-item dropdown">
            <a
              class="nav-link dropdown-toggle"
              href="/oyun-aletleri-c-196"
              id="mega-menu-196"
              role="button"
            >
              OYUN ALETLERİ
            </a>
          </li>
          <li class="nav-item dropdown">
            <a
              class="nav-link dropdown-toggle"
              href="/pelus-oyuncak-c-197"
              id="mega-menu-197"
              role="button"
            >
              peluş oyuncak
            </a>
          </li>
          <li class="nav-item dropdown">
            <a
              class="nav-link dropdown-toggle"
              href="/elektronik-c-154"
              id="mega-menu-154"
              role="button"
            >
              Elektronik
            </a>
            <div class="dropdown-menu" aria-labelledby="mega-menu-154">
              <div class="container">
                <div class="mega-menu-container">
                  <div class="row">
                    <div class="col-md-9">
                      <div class="row">
                        <div class="col">
                          <ul>
                            <li>
                              <a
                                class="sub-title"
                                href="/elektronik/mobil-mobil-aksesuar-c-185"
                              >
                                Mobil &amp; Mobil Aksesuar
                              </a>
                            </li>
                            <li>
                              <a
                                href="/elektronik/mobil-mobil-aksesuar/sarj-kablolari-c-190"
                              >
                                Şarj Kabloları
                              </a>
                            </li>
                            <li>
                              <a
                                href="/elektronik/mobil-mobil-aksesuar/powerbank-c-191"
                              >
                                Powerbank
                              </a>
                            </li>
                          </ul>
                          <ul>
                            <li>
                              <a
                                class="sub-title"
                                href="/elektronik/tv-goruntu-ses-sistemleri-c-159"
                              >
                                TV, Görüntü &amp; Ses Sistemleri
                              </a>
                            </li>
                            <li>
                              <a
                                href="/elektronik/tv-goruntu-ses-sistemleri/ses-sistemleri-c-182"
                              >
                                Ses Sistemleri
                              </a>
                            </li>
                            <li>
                              <a
                                href="/elektronik/tv-goruntu-ses-sistemleri/goruntu-sistemleri-c-183"
                              >
                                Görüntü Sistemleri
                              </a>
                            </li>
                          </ul>
                        </div>
                        <div class="col">
                          <ul>
                            <li>
                              <a
                                class="sub-title"
                                href="/elektronik/akilli-saat-bileklikler-c-155"
                              >
                                Akıllı Saat &amp; Bileklikler
                              </a>
                            </li>
                          </ul>
                        </div>
                        <div class="col">
                          <ul>
                            <li>
                              <a
                                class="sub-title"
                                href="/elektronik/aydinlatma-sistemleri-c-156"
                              >
                                Aydınlatma Sistemleri
                              </a>
                            </li>
                          </ul>
                        </div>
                        <div class="col">
                          <ul>
                            <li>
                              <a
                                class="sub-title"
                                href="/elektronik/bilgisayar-tablet-c-157"
                              >
                                Bilgisayar &amp; Tablet
                              </a>
                            </li>
                            <li>
                              <a
                                href="/elektronik/bilgisayar-tablet/klavye-c-186"
                              >
                                Klavye
                              </a>
                            </li>
                            <li>
                              <a
                                href="/elektronik/bilgisayar-tablet/mouse-c-187"
                              >
                                Mouse
                              </a>
                            </li>
                            <li>
                              <a
                                href="/elektronik/bilgisayar-tablet/kulakliklar-c-188"
                              >
                                Kulaklıklar
                              </a>
                            </li>
                            <li>
                              <a
                                href="/elektronik/bilgisayar-tablet/kablolar-c-189"
                              >
                                Kablolar
                              </a>
                            </li>
                            <li>
                              <a
                                href="/elektronik/bilgisayar-tablet/goruntu-aktaricilari-c-192"
                              >
                                Görüntü Aktarıcıları
                              </a>
                            </li>
                            <li>
                              <a
                                href="/elektronik/bilgisayar-tablet/gamepads-c-193"
                              >
                                Gamepads
                              </a>
                            </li>
                          </ul>
                        </div>
                        <div class="col">
                          <ul>
                            <li>
                              <a
                                class="sub-title"
                                href="/elektronik/kucuk-ev-aletleri-c-158"
                              >
                                Küçük Ev Aletleri
                              </a>
                            </li>
                          </ul>
                        </div>
                      </div>
                    </div>
                    <div class="col-md-3">
                      <a
                        href="/elektronik-c-154"
                        class="d-block mb-3"
                        ><img
                          src="../assets/icons/elektronik.png"
                          alt=""
                      /></a>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </li>
          <li class="nav-item dropdown">
            <a
              class="nav-link dropdown-toggle"
              href="/ev-ofis-c-160"
              id="mega-menu-160"
              role="button"
            >
              Ev &amp; Ofis
            </a>
            <div class="dropdown-menu" aria-labelledby="mega-menu-160">
              <div class="container">
                <div class="mega-menu-container">
                  <div class="row">
                    <div class="col-md-9">
                      <div class="row">
                        <div class="col">
                          <ul>
                            <li>
                              <a
                                class="sub-title"
                                href="/ev-ofis/aydinlatma-sistemleri-c-161"
                              >
                                Aydınlatma Sistemleri
                              </a>
                            </li>
                          </ul>
                        </div>
                        <div class="col">
                          <ul>
                            <li>
                              <a
                                class="sub-title"
                                href="/ev-ofis/banyo-tuvalet-c-162"
                              >
                                Banyo &amp; Tuvalet
                              </a>
                            </li>
                          </ul>
                        </div>
                        <div class="col">
                          <ul>
                            <li>
                              <a
                                class="sub-title"
                                href="/ev-ofis/ev-ofis-gerecleri-c-163"
                              >
                                Ev &amp; Ofis Gereçleri
                              </a>
                            </li>
                          </ul>
                        </div>
                        <div class="col">
                          <ul>
                            <li>
                              <a
                                class="sub-title"
                                href="/ev-ofis/mutfak-gerecleri-c-164"
                              >
                                Mutfak Gereçleri
                              </a>
                            </li>
                          </ul>
                        </div>
                      </div>
                    </div>
                    <div class="col-md-3">
                      <a
                        href="/ev-ofis-c-160"
                        class="d-block mb-3"
                        ><img
                          src="../assets/icons/ev-ofis.png"
                          alt=""
                      /></a>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </li>
          <li class="nav-item dropdown">
            <a
              class="nav-link dropdown-toggle"
              href="/kisisel-bakim-c-165"
              id="mega-menu-165"
              role="button"
            >
              Kişisel Bakım
            </a>
            <div class="dropdown-menu" aria-labelledby="mega-menu-165">
              <div class="container">
                <div class="mega-menu-container">
                  <div class="row">
                    <div class="col-md-9">
                      <div class="row">
                        <div class="col">
                          <ul>
                            <li>
                              <a
                                class="sub-title"
                                href="/kisisel-bakim/kisisel-bakim-aletleri-c-184"
                              >
                                Kişisel Bakım Aletleri
                              </a>
                            </li>
                          </ul>
                        </div>
                        <div class="col">
                          <ul>
                            <li>
                              <a
                                class="sub-title"
                                href="/kisisel-bakim/epilasyon-agda-c-166"
                              >
                                Epilasyon &amp; Ağda
                              </a>
                            </li>
                          </ul>
                        </div>
                        <div class="col">
                          <ul>
                            <li>
                              <a
                                class="sub-title"
                                href="/kisisel-bakim/kozmetik-c-167"
                              >
                                Kozmetik
                              </a>
                            </li>
                          </ul>
                        </div>
                        <div class="col">
                          <ul>
                            <li>
                              <a
                                class="sub-title"
                                href="/kisisel-bakim/medikal-c-168"
                              >
                                Medikal
                              </a>
                            </li>
                          </ul>
                        </div>
                        <div class="col">
                          <ul>
                            <li>
                              <a
                                class="sub-title"
                                href="/kisisel-bakim/sac-sakal-bakim-c-169"
                              >
                                Saç &amp; Sakal Bakım
                              </a>
                            </li>
                          </ul>
                        </div>
                      </div>
                    </div>
                    <div class="col-md-3">
                      <a
                        href="/kisisel-bakim-c-165"
                        class="d-block mb-3"
                        ><img
                          src="../assets/icons/kisiselbakim.png"
                          alt=""
                      /></a>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </li>
          <li class="nav-item dropdown">
            <a
              class="nav-link dropdown-toggle"
              href="/otomotiv-yapi-market-c-170"
              id="mega-menu-170"
              role="button"
            >
              Otomotiv &amp; Yapı Market
            </a>
            <div class="dropdown-menu" aria-labelledby="mega-menu-170">
              <div class="container">
                <div class="mega-menu-container">
                  <div class="row">
                    <div class="col-md-9">
                      <div class="row">
                        <div class="col">
                          <ul>
                            <li>
                              <a
                                class="sub-title"
                                href="/otomotiv-yapi-market/hobi-c-171"
                              >
                                Hobi
                              </a>
                            </li>
                          </ul>
                        </div>
                        <div class="col">
                          <ul>
                            <li>
                              <a
                                class="sub-title"
                                href="/otomotiv-yapi-market/motosiklet-c-172"
                              >
                                Motosiklet
                              </a>
                            </li>
                          </ul>
                        </div>
                        <div class="col">
                          <ul>
                            <li>
                              <a
                                class="sub-title"
                                href="/otomotiv-yapi-market/otomotiv-c-173"
                              >
                                Otomotiv
                              </a>
                            </li>
                          </ul>
                        </div>
                        <div class="col">
                          <ul>
                            <li>
                              <a
                                class="sub-title"
                                href="/otomotiv-yapi-market/yapi-market-c-174"
                              >
                                Yapı Market
                              </a>
                            </li>
                          </ul>
                        </div>
                      </div>
                    </div>
                    <div class="col-md-3">
                      <a
                        href="/otomotiv-yapi-market-c-170"
                        class="d-block mb-3"
                        ><img
                          src="../assets/icons/otomotiv-yapi.png"
                          alt=""
                      /></a>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </li>
        </ul>
      </div>
    </div>
  </section>
</template>

<style>
.mega-menu .dropdown {
    position: static;
}

 .mega-menu .dropdown-menu {
    border-top: 0;
    border-radius: 3px;
    background-color: #fff;
    width: 100%;
    left:0;
    right:0;
    top:47px;
    position: absolute;
    -webkit-box-shadow: 0px 0px 5px 0px rgba(0,0,0,0.3);
    -moz-box-shadow: 0px 0px 5px 0px rgba(0,0,0,0.3);
    box-shadow: 0px 0px 5px 0px rgba(0,0,0,0.3);
}
    
.mega-menu .dropdown:hover .dropdown-menu, 
 .mega-menu .dropdown .dropdown-menu:hover {
    display:block!important;
 }

</style>