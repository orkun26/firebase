<template>
  <div class="p-g-mod-body-p-0">
    <div class="stores">
      <div class="container">
        <div class="cards">
          <div class="card mt-3">
            <div class="card-body">
              <a
                href="/"
                target="_blank"
                ><img
                  src="https://www.toptanal.com/template/smart/default/assets/images/gittigidiyor.png?v=1578594916"
                  class="d-block w-100"
                  alt="GittiGidiyor Mağazamız"
              /></a>
            </div>
          </div>
          <div class="card mt-3">
            <div class="card-body">
              <a
                href="https://www.n11.com/magaza/barindirticaret"
                target="_blank"
                ><img
                  src="https://www.toptanal.com/template/smart/default/assets/images/n11.png?v=1578594916"
                  class="d-block w-100"
                  alt="N11 Mağazamız"
              /></a>
            </div>
          </div>
          <div class="card mt-3">
            <div class="card-body">
              <a
                href="https://www.hepsiburada.com/magaza/toptanalelektronik"
                target="_blank"
                ><img
                  src="https://www.toptanal.com/template/smart/default/assets/images/hepsiburada.png?v=1578594917"
                  class="d-block w-100"
                  alt="Hepsiburada Mağazamız"
              /></a>
            </div>
          </div>
          <div class="card mt-3">
            <div class="card-body">
              <a
                href="https://www.epttavm.com/magaza/toptanalelektronik"
                target="_blank"
                ><img
                  src="https://www.toptanal.com/template/smart/default/assets/images/epttavm.png?v=1578594916"
                  class="d-block w-100"
                  alt="ePttAVM Mağazamız"
              /></a>
            </div>
          </div>
        </div>
      </div>
    </div>
    <footer>
      <div class="promotion-list">
        <div class="container">
          <div class="row">
            <div class="col">
              <div class="box">
                <img  src="../assets/subimages/kapidaodeme.PNG" />
                <span class="name-1">KAPIDA ÖDEME</span
                ><span class="name-2">Nakit &amp; Kredi Kartı</span>
              </div>
            </div>
            <div class="col">
              <div class="box">
                 <img  src="../assets/subimages/whatsappsub.PNG" />
                <span class="name-1">WHATSAPP</span
                ><span class="name-2">9005544711414</span>
              </div>
            </div>
            <div class="col">
              <div class="box">
                <img  src="../assets/subimages/sub3.PNG" />
               <span class="name-1">İADE &amp; DEĞİŞİM</span
                ><span class="name-2">14 Gün Koşulsuz</span>
              </div>
            </div>
            <div class="col">
              <div class="box">
                 <img  src="../assets/subimages/ucretsizıadesub.PNG" />
                <span class="name-1">ÜCRETSİZ KARGO</span
                ><span class="name-2">Yurtiçi Tüm Kargolar</span>
              </div>
            </div>
            <div class="col">
              <div class="box">
                 <img  src="../assets/subimages/12taksitsub.PNG" />
                <span class="name-1">12 TAKSİT</span
                ><span class="name-2">Tüm Kredi Kartlarına</span>
              </div>
            </div>
            <div class="col">
              <div class="box">
                 <img  src="../assets/subimages/Yurtdisikargosub.PNG" />
                <span class="name-1">YURTDIŞI KARGO</span
                ><span class="name-2">Tüm Dünyaya Kargo</span>
              </div>
            </div>
          </div>
        </div>
      </div>
      <div class="bb">
        <div class="container">
          <div class="row">
            <div class="col-md-4">
              <div class="logo-area">
                <a href="/" class="logo"
                  ><img
                    src="../assets/icons/toptanalogo.png"
                    alt=""
                /></a>
              </div>
              <div class="social-media">
                <a
                  href="/"
                  class="fb"
                  target="_blank"
                  > <img  src="../assets/subimages/facebooksub.PNG" /></a
                ><a
                  href="/"
                  class="tw"
                  target="_blank"
                  > <img  src="../assets/subimages/twittersub.PNG" /></a
                ><a
                  href="/"
                  class="ins"
                  target="_blank"
                  > <img  src="../assets/subimages/ınstagramsub.PNG" /></a
                ><a
                  href="/"
                  class="yt"
                  target="_blank"
                  > <img  src="../assets/subimages/youtubesub.PNG" /></a>
              </div>
              <div class="secure mt-2">
                <div class="title-3">%100 Güvenli Ödeme</div>
                <div class="description">
                  Tüm kredi kartı bilgileriniz 256bit SSL Sertifikası ile
                  korunmaktadır.
                </div>
              </div>
            </div>
            <div class="col-md-8">
              <div class="info">
                <div class="row">
                  <div class="col-md-4">
                    <div class="title text-left" onclick="$('.f1').toggle()">
                      Kurumsal
                    </div>
                    <div class="fs f1">
                      <ul>
                        <li>
                          <a href="/hakkimizda-sID1">
                            Hakkımızda
                          </a>
                        </li>
                        <li>
                          <a
                            href="/gizlilik-sozlesmesi-sID2"
                          >
                            Gizlilik Sözleşmesi
                          </a>
                        </li>
                        <li>
                          <a
                            href="/kullanici-sozlesmesi-sID3"
                          >
                            Kullanıcı Sözleşmesi
                          </a>
                        </li>
                        <li>
                          <a href="/iletisim-sID4">
                            İletişim
                          </a>
                        </li>
                        <li>
                          <a href="/sss-sID0">
                            Sıkça Sorulan Sorular
                          </a>
                        </li>
                        <li>
                          <a href="/siparis-takip-sID0">
                            Sipariş Takip
                          </a>
                        </li>
                        <li>
                          <a
                            href="/havale-bildirim-sID0"
                          >
                            Havale Bildirimleri
                          </a>
                        </li>
                      </ul>
                    </div>
                  </div>
                  <div class="col-md-4">
                    <div class="title text-left" onclick="$('.f2').toggle()">
                      Kategoriler
                    </div>
                    <div class="fs f2">
                      <ul>
                        <li>
                          <a href="/11-yila-ozel-c-194">
                            11. Yıla Özel
                          </a>
                        </li>
                        <li>
                          <a
                            href="/oyun-aletleri-c-196"
                          >
                            OYUN ALETLERİ
                          </a>
                        </li>
                        <li>
                          <a
                            href="/pelus-oyuncak-c-197"
                          >
                            peluş oyuncak
                          </a>
                        </li>
                        <li>
                          <a href="/elektronik-c-154">
                            Elektronik
                          </a>
                        </li>
                        <li>
                          <a href="/ev-ofis-c-160">
                            Ev &amp; Ofis
                          </a>
                        </li>
                        <li>
                          <a
                            href="/kisisel-bakim-c-165"
                          >
                            Kişisel Bakım
                          </a>
                        </li>
                        <li>
                          <a
                            href="/otomotiv-yapi-market-c-170"
                          >
                            Otomotiv &amp; Yapı Market
                          </a>
                        </li>
                        <li>
                          <a
                            href="/spor-outdoor-hobi-c-175"
                          >
                            Spor &amp; Outdoor &amp; Hobi
                          </a>
                        </li>
                      </ul>
                    </div>
                  </div>
                  <div class="col-md-4">
                    <div class="title text-left" onclick="$('.f3').toggle()">
                      Bize Ulaşın
                    </div>
                    <div class="fs f3">
                      <strong>Toptanal&nbsp; İletişim Adres Bilgileri :</strong
                      ><br /><br /><strong
                        >Çalışma Saatlerimiz :<br />
                        Pazartesi - Cuma:09:00-17:30-Cumartesi:12:00</strong
                      ><br /><br /><strong>Adres Bilgilerimiz :</strong><br />
                      Ord. Porf. Cemil Birsel Cad. Paçacı Sokak No:11 K:3 D:48
                      Tahtakale Eminönü/İstanbul<br /><br /><strong
                        >Telefon :</strong
                      >
                      0212 522 86 83<br /><strong>Gsm :</strong> 0554 471 14
                      14<br /><strong>WhatsApp :</strong> 0553 430 15 00<br /><strong
                        >E- Posta :</strong
                      >
                      siparis@toptanal.com
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <div class="row footer-text">
            <div class="col-md-12 text-center"></div>
          </div>
        </div>
      </div>
      <div class="bar-2">
        <div class="container">
          <div class="row">
            <div class="col-md-12 text-center">
              <img
                class="lazy-load cards lazy-complete"
                alt=""
                src="https://www.toptanal.com/theme/toptanal/assets/images/cards-2.png?v=1597435470"
                style=""
              />
            </div>
          </div>
        </div>
      </div>
    </footer>
  </div>
</template>
<style>
