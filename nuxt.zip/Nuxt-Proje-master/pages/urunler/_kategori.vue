<template>

</template>

<script>
export default {
  name: '_category',
  created() {
    const category = this.$route.params.category;
  }
}
</script>

<style scoped>

</style>