
<template>
  <div class="container">
    <UyeKayit />
  </div>
</template>

<script>
import UyeKayit from "../components/UyeKayit";
export default {
    components:{
        UyeKayit,
    }
  
};
</script>